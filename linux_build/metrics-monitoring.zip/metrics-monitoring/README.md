[![cisc6597](https://circleci.com/gh/cisc6597/metrics-monitoring.svg?style=shield&circle-token=1516c6fe46836362afb10ffed0f9517398d9aedc)](https://app.circleci.com/pipelines/github/cisc6597/metrics-monitoring)


This repository will be used for my CISC 6597 Capstone project. Official name is subject to change, current name is a place holder.

Project details and a detailed readme will be developed throughout this project.

Stay tuned.
